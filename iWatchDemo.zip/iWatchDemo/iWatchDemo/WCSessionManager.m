//
//  WCSessionManager.m
//  iWatchDemo
//
//  Created by silicon on 17/2/22.
//  Copyright © 2017年 com.snailgames. All rights reserved.
//

#import "WCSessionManager.h"

@implementation WCSessionManager

+ (WCSessionManager *)shareSession{
    
    return nil;
}

@end
