//
//  WCSessionManager.h
//  iWatchDemo
//
//  Created by silicon on 17/2/22.
//  Copyright © 2017年 com.snailgames. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WCSessionManager : NSObject

+ (WCSessionManager *)shareSession;

@end
